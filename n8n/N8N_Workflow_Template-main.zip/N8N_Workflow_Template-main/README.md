Clause de non-responsabilité

Avant d'utiliser ces workflow, il est impératif de consulter les réglementations en vigueur applicables à votre secteur d'activité et à votre région. L'utilisation de ce workflow doit être conforme à toutes les lois et réglementations pertinentes.

Veuillez noter que l'auteur de ce workflow décline toute responsabilité légale quant à son utilisation. L'utilisateur est seul responsable de s'assurer que l'application de ce workflow respecte les exigences légales et réglementaires en vigueur.
